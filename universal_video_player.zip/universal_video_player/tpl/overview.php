<div class="wrap">
		<div id="lbg_logo">
			<h2><?php esc_html_e( 'Overview', 'universal-video' );?></h2>
		</div>
		<div class="postbox-container lbg_w100">
			<div class="postbox">
				<h3 class="lbg_p710"><?php esc_html_e( 'Universal Video Player - YouTube, Vimeo and Self-Hosted Videos', 'universal-video' );?></h3>
				<div class="inside">
				<p><?php esc_html_e( 'This plugin will allow you to insert an advanced HTML5 Video Player With Playlist, Categories and Search', 'universal-video' );?></p>
				<p><?php esc_html_e( 'You have available the following sections', 'universal-video' );?>:</p>
				<ul class="lbg_list-1">
					<li><a href="?page=UNIVERSAL_VIDEO_PLAYER_Manage_Players"><?php esc_html_e( 'Manage Players', 'universal-video' );?></a></li>
					<li><a href="?page=UNIVERSAL_VIDEO_PLAYER_Add_New"><?php esc_html_e( 'Add New', 'universal-video' );?></a> <?php esc_html_e( '(player)', 'universal-video' );?></li>
					<li><a href="?page=UNIVERSAL_VIDEO_PLAYER_Manage_Categories"><?php esc_html_e( 'Manage Categories', 'universal-video' );?></a>
		          <li><a href="?page=UNIVERSAL_VIDEO_PLAYER_Help"><?php esc_html_e( 'Help', 'universal-video' );?></a></li>
				</ul>
			  </div>
			</div>
		</div>
	</div>
