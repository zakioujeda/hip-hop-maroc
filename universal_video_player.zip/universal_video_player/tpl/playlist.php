<div class="wrap">
	<div id="lbg_logo">
			<h2><?php esc_html_e( 'Playlist for player:', 'universal-video' );?> <span class="lbg_the_redb"><?php esc_html_e($_COOKIE['xname']);?> - <?php esc_html_e( 'ID', 'universal-video' );?> #<?php esc_html_e($_COOKIE['xid']);?></span></h2>
 	</div>
  <div id="universal_video_player_updating_witness"><img src="<?php echo plugins_url('images/ajax-loader.gif', dirname(__FILE__))?>" /> <?php esc_html_e( 'Updating...', 'universal-video' );?></div>
<div class="lbg_cent_p0"><img src="<?php echo plugins_url('images/icons/add_icon.gif', dirname(__FILE__))?>" alt="add" align="absmiddle" /> <a href="?page=UNIVERSAL_VIDEO_PLAYER_Playlist&xmlf=add_playlist_record"><?php esc_html_e( 'Add new', 'universal-video' );?></a>  &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp; <img src="<?php echo plugins_url('images/icons/magnifier.png', dirname(__FILE__))?>" alt="add" align="absmiddle" /> <a href="javascript: void(0);" onclick="showDialogPreview(<?php echo strip_tags($_COOKIE['xid'])?>)"><?php esc_html_e( 'Preview Player', 'universal-video' );?></a></div>
<div class="lbg_pad_5_0">#<?php esc_html_e( 'Initial Order --- Video File Title', 'universal-video' );?></div>

<div id="previewDialog"><iframe id="previewDialogIframe" src="" width="100%" height="600" class="lbg_b0"></iframe></div>

<ul id="universal_video_player_sortable">
	<?php foreach ( $result as $row )
	{
		$row=universal_video_player_unstrip_array($row);
		$element_to_show=$row['title'];
		if ($row['youtube']) {
			$element_to_show.=' - YouTube ID: '.$row['youtube'];
		}
		if ($row['vimeo']) {
			$element_to_show.=' - Vimeo ID: '.$row['vimeo'];
		}


	?>
	<li class="ui-state-default cursor_move" id="<?php echo esc_attr($row['id']);?>">#<?php echo esc_attr($row['ord']);?> --- <span id="mov_title_<?php echo esc_attr($row['id']);?>"><?php esc_html_e($element_to_show);?></span> <div class="toogle-btn-closed" id="toogle-btn<?php echo esc_attr($row['ord']);?>" onclick="mytoggle('toggleable<?php echo esc_js($row['ord']);?>','toogle-btn<?php echo esc_js($row['ord']);?>');"></div><div class="options"><a href="javascript: void(0);" onclick="universal_video_player_delete_entire_record(<?php echo esc_js($row['id']);?>,<?php echo esc_js($row['ord']);?>);" class="lbg_the_red"><?php esc_html_e( 'Delete', 'universal-video' );?></a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="?page=UNIVERSAL_VIDEO_PLAYER_Playlist&amp;id=<?php echo strip_tags($_COOKIE['xid'])?>&amp;name=<?php echo esc_attr($_COOKIE['xname'])?>&amp;duplicate_id=<?php echo esc_attr($row['id']);?>"><?php esc_html_e( 'Duplicate', 'universal-video' );?></a></div>
	<div class="toggleable" id="toggleable<?php echo esc_attr($row['ord'])?>">
    <form method="POST" enctype="multipart/form-data" id="form-playlist-universal_video-<?php echo esc_attr($row['ord'])?>">
	    <input name="id" type="hidden" value="<?php echo esc_attr($row['id'])?>" />
        <input name="ord" type="hidden" value="<?php echo esc_attr($row['ord'])?>" />
		<table width="100%" cellspacing="0" class="wp-list-table widefat fixed pages lbg_bgFF">
		  <tr>
		    <td align="left" valign="middle" width="25%"></td>
		    <td align="left" valign="middle" width="77%"></td>
		  </tr>
		  <tr>
		    <td align="right" valign="middle" class="row-title"><?php esc_html_e( 'Title', 'universal-video' );?></td>
		    <td align="left" valign="top"><input name="title" type="text" size="80" id="title" value="<?php echo esc_attr($row['title'])?>"/></td>
		    </tr>
		  <tr>
		    <td align="right" valign="middle" class="row-title"><?php esc_html_e( 'Description', 'universal-video' );?></td>
		    <td align="left" valign="top"><input name="desc" type="text" size="80" id="desc" value="<?php echo esc_attr($row['desc'])?>"/></td>
		  </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Category', 'universal-video' );?></td>
		    <td align="left" valign="top"><?php foreach ( $result_categ as $row_categ )
				{
					$row_categ=universal_video_player_unstrip_array($row_categ);
					$checked_var='';
					if (preg_match_all('/\b'.$row_categ["id"].'\b/', $row['category'], $matches)) { $checked_var='checked="checked"'; }
					?>
				<p><input name="category[]" id="category" type="checkbox" value="<?php echo esc_attr($row_categ['id'])?>" <?php echo esc_attr($checked_var); ?> /> <?php esc_html_e($row_categ['categ'])?></p>
				<?php }	?></td>
		    </tr>
			<tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Playlist Image ', 'universal-video' );?></td>
		    <td align="left" valign="top"><input name="imgplaylist" type="text" id="imgplaylist" size="80" value="<?php echo stripslashes($row['imgplaylist'])?>" /> <input name="upload_imgplaylist_button_universal_player_<?php echo esc_attr($row['ord'])?>" type="button" id="upload_imgplaylist_button_universal_player_<?php echo esc_attr($row['ord'])?>" value="Upload Image" />
		      <br />
		      <?php esc_html_e('Enter an URL or upload an image', 'universal-video' );?><br />
              <div id="lbg-universal_video_playlistimg_div_<?php echo esc_attr($row['ord'])?>" class="lbg_left_p0"> <img src="<?php echo esc_attr($row['imgplaylist'])?>" alt="" name="imgplaylist_<?php echo esc_attr($row['ord'])?>" id="imgplaylist_<?php echo esc_attr($row['ord'])?>" /> </div></td>
	      </tr>
          <tr>
            <td align="right" valign="top" class="row-title"><?php esc_html_e( 'YouTube Video ID', 'universal-video' );?></td>
            <td align="left" valign="top"><input name="youtube" type="text" size="60" id="youtube" value="<?php echo stripslashes($row['youtube']);?>"/></td>
            </tr>
          <tr>
            <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Vimeo Video ID', 'universal-video' );?></td>
            <td align="left" valign="top"><input name="vimeo" type="text" size="60" id="vimeo" value="<?php echo stripslashes($row['vimeo']);?>"/></td>
            </tr>

		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Self Hosted/Third Party Hosted Video .MP4 file', 'universal-video' );?></td>
		    <td align="left" valign="top"><input name="mp4" type="text" id="mp4" size="80" value="<?php echo stripslashes($row['mp4'])?>" />
		      <input name="upload_mp4_button_universal_player_<?php echo esc_attr($row['ord'])?>" type="button" id="upload_mp4_button_universal_player_<?php echo esc_attr($row['ord'])?>" value="Change File" />
		      <br />
		      <?php esc_html_e( 'Enter an URL or upload the file', 'universal-video' );?></td></td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Self Hosted/Third Party Hosted Video .WEBM file', 'universal-video' );?></td>
		    <td align="left" valign="top"><input name="webm" type="text" id="webm" size="80" value="<?php echo stripslashes($row['webm'])?>" />
		      <input name="upload_webm_button_universal_player_<?php echo esc_attr($row['ord'])?>" type="button" id="upload_webm_button_universal_player_<?php echo esc_attr($row['ord'])?>" value="Change File" />
		      <br />
		      <?php esc_html_e( 'Enter an URL or upload the file', 'universal-video' );?></td></td>
	      </tr>
				<tr>
			    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Optional Start Time', 'universal-video' );?></td>
			    <td align="left" valign="top"><input name="startpoint" type="text" size="60" id="startpoint" value="<?php echo stripslashes($row['startpoint']);?>"/> <?php esc_html_e( 'HH:MM:SS', 'universal-video' );?></td>
		      </tr>
					<tr>
				    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Optional End Time', 'universal-video' );?></td>
				    <td align="left" valign="top"><input name="endpoint" type="text" size="60" id="endpoint" value="<?php echo stripslashes($row['endpoint']);?>"/> <?php esc_html_e( 'HH:MM:SS', 'universal-video' );?></td>
			      </tr>

		  <tr>
		    <td align="right" valign="middle" class="row-title">&nbsp;</td>
		    <td align="left" valign="middle">&nbsp;</td>
		    </tr>
		  <tr>
		    <td colspan="2" align="left" valign="middle">&nbsp;</td>
		    </tr>
		  <tr>
		    <td colspan="2" align="center" valign="middle"><input name="Submit<?php echo esc_attr($row['ord'])?>" id="Submit<?php echo esc_attr($row['ord'])?>" type="submit" class="button-primary" value="Update Playlist Record"></td>
		  </tr>
		</table>
        </form>
            <div id="ajax-message-<?php echo esc_attr($row['ord'])?>" class="ajax-message"></div>
    </div>
    </li>
	<?php } ?>
</ul>





</div>
