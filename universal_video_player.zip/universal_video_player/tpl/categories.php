<div class="wrap">
	<div id="lbg_logo">
			<h2><?php esc_html_e( 'Manage Categories', 'universal-video' );?></h2>
 	</div>
    <div>
      <p><?php esc_html_e( 'From this section you manage the categories.', 'universal-video' );?></p></div>

<div class="lbg_cent_p0"><img src="<?php echo plugins_url('images/icons/add_icon.gif', dirname(__FILE__))?>" alt="add" align="absmiddle" /> <a href="?page=UNIVERSAL_VIDEO_PLAYER_Add_New_Category"><?php esc_html_e( 'Add new (category)', 'universal-video' );?></a></div>

<table width="100%" class="widefat">

			<thead>
				<tr>
					<th scope="col" width="8%"><?php esc_html_e( 'ID', 'universal-video' );?></th>
					<th scope="col" width="58%"><?php esc_html_e( 'Category Name', 'universal-video' );?> <span class="lbg_11_it"><?php esc_html_e( '(click category name to edit it)', 'universal-video' );?></span></th>
					<th scope="col" width="34%"><?php esc_html_e( 'Action', 'universal-video' );?></th>
				</tr>
			</thead>

<tbody>
<?php foreach ( $result as $row )
	{
		$row=universal_video_player_unstrip_array($row); ?>
							<tr class="alternate author-self status-publish" valign="top">
					<td><?php esc_html_e($row['id']);?></td>
					<td><div id="editme<?php echo esc_attr($row['id']);?>"><?php esc_html_e($row['categ']);?></div>
						<script>
												jQuery("#editme<?php echo esc_js($row['id'])?>").on( "keydown", function(event) {
										      if(event.which == 13)
										         event.preventDefault();
										    });
                        jQuery("#editme<?php echo esc_js($row['id'])?>").editInPlace({
                                saving_animation_color: "#9df084",
                                callback: function(idOfEditor, enteredText, orinalHTMLContent, settingsParams, animationCallbacks) {
																				enteredText=enteredText.replace(/<\S[^><]*>/g,"");
																				enteredText=enteredText.replace(/&/g,"");
																				if (enteredText!='') {
																					animationCallbacks.didStartSaving();
																					setTimeout(animationCallbacks.didEndSaving, 2000);
																					updateCategory(<?php echo esc_js($row['id'])?>,enteredText);
																				} else {
																					enteredText=orinalHTMLContent;
																				}

                                    		return enteredText;
                                }
                            });
                        </script>
                    </td>
					<td>
                        <a href="?page=UNIVERSAL_VIDEO_PLAYER_Manage_Categories&id=<?php echo esc_attr($row['id'])?>" onclick="return confirm('Are you sure?')" class="lbg_the_red"><?php esc_html_e( 'Delete', 'universal-video' );?></a>
                        </td>
	            </tr>
<?php } ?>
						</tbody>
		</table>





</div>
