<div class="wrap">
<div id="lbg_logo">
			<h2><?php esc_html_e( 'Help', 'universal-video' );?></h2>
  </div>
<p><?php esc_html_e( 'This plugin requires at least WordPress 3.0', 'universal-video' );?></p>
<ul class="lbg_list-1">
  <li><a href="#videotutorials"><?php esc_html_e( 'Video Tutorials', 'universal-video' );?></a></li>
  <li><a href="#instalation"><?php esc_html_e( 'Plugin Instalation', 'universal-video' );?></a></li>
  <li><a href="#structure"><?php esc_html_e( 'Files &amp; Folders Structure', 'universal-video' );?></a></li>
  <li><a href="#manageplayers"><?php esc_html_e( 'Manage Players', 'universal-video' );?></a></li>
  <li><a href="#settings"><?php esc_html_e( 'Player Settings', 'universal-video' );?></a></li>
  <li><a href="#playlist"><?php esc_html_e( 'Playlist', 'universal-video' );?></a></li>
  <li><a href="#facebook_share"><?php esc_html_e( 'FaceBook Share', 'universal-video' );?></a></li>
  <li><a href="#shortcode"><?php esc_html_e( 'ShortCode', 'universal-video' );?></a></li>
  <li>.<a href="#htaccess"><?php esc_html_e( 'htaccess', 'universal-video' );?></a></li>
	<li>.<a href="#api"><?php esc_html_e( 'API function', 'universal-video' );?></a></li>
</ul>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span class="lbg_subtitle"><a name="videotutorials" id="videotutorials"></a><?php esc_html_e( 'Video Tutorials', 'universal-video' );?></span></p>
<p><?php esc_html_e( 'Step 1: Installation', 'universal-video' );?> - <a href="https://www.youtube.com/watch?v=rAFJMLyKvvs" target="_blank">https://www.youtube.com/watch?v=rAFJMLyKvvs</a><br />
<?php esc_html_e( 'Step 2: Create a new player and manage the player settings', 'universal-video' );?> - <a href="https://www.youtube.com/watch?v=XwNqOK0UCFE" target="_blank">https://www.youtube.com/watch?v=XwNqOK0UCFE</a><br />
<?php esc_html_e( 'Step 3: Manage the playlist and categories', 'universal-video' );?> - <a href="https://www.youtube.com/watch?v=49Uo9JGm1wk" target="_blank">https://www.youtube.com/watch?v=49Uo9JGm1wk</a><br />
<span class="regb"><?php esc_html_e( 'NEW:', 'universal-video' );?> </span><?php esc_html_e( 'Automatically Obtain Thumbnail, Title &amp; Description From YouTube Server', 'universal-video' );?> - <a href="https://www.youtube.com/watch?v=r_NRQJ-uiKI" target="_blank">https://www.youtube.com/watch?v=r_NRQJ-uiKI</a></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p class="lbg_subtitle"><a name="instalation" id="instalation"></a><?php esc_html_e( 'Plugin Instalation', 'universal-video' );?></p>
<p><?php esc_html_e( 'Step 1. Enter in your wordpress CMS and go to Plugins menu', 'universal-video' );?><br />
<?php esc_html_e( 'Step 2. Under Plugins menu click &quot;Add New&quot;', 'universal-video' );?><br />
<?php esc_html_e( 'Step 3. Select &quot;Upload&quot;, choose the archive universal_video_player.zip that you downloaded and hit &quot;Install Now&quot;', 'universal-video' );?><br />
<?php esc_html_e( 'Step 4. After the plugin is installed click &quot;Activate Plugin&quot;', 'universal-video' );?><br />
<a href="#shortcode"><?php esc_html_e( 'click here', 'universal-video' );?></a> <?php esc_html_e( 'for more details regarding the shortcode', 'universal-video' );?></p>
<p>&nbsp;</p>
<p class="lbg_subtitle"><a name="structure" id="structure"></a><?php esc_html_e( 'Files &amp; Folders Structure', 'universal-video' );?></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'css', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'the folder contains the .css files used by the pluging', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'images', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'the folder contains the images used by the pluging', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'js', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'the folder contains the .js files used by the pluging', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'universal_video_player', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'the folder contains the .js &amp; .css files that the video player use', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'tpl', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'the folder contains the template files used by the pluging', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'universal_video_player.php', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'the plugin itself', 'universal-video' );?></td>
  </tr>
  <tr>
    <td width="22%" align="left" valign="top" class="row-title">&nbsp;</td>
    <td width="78%" align="left" valign="top">&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
<p><span class="lbg_subtitle"><a name="manageplayers" id="playlist2"></a>Manage Players</span></p>
<p>From this section you can define the players. <br />
  If you need to include multiple players in your pages with different settings   and playlist you can define the players and manage the settings for each one.<br />
If you need only one player in your website, just edit the default one.</p>
<p>&nbsp;</p>
<p class="lbg_subtitle"><a name="settings" id="settings"></a>Player Settings</p>
<p>From this section you can define the video player  settings.</p>
<table class="wp-list-table widefat fixed pages" cellspacing="0">
  <tr>
    <td width="30%" align="left" valign="top" class="row-title"></td>
    <td width="83%" align="left" valign="top"></td>
  </tr>
  <tr>
    <td colspan="2" align="left" valign="top" class="lbg_regGray"><?php esc_html_e( 'General settings', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Skin', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?><br />
      - whiteControllers<br />
    - blackControllers</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Player Width', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'plugin width', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Player Height', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'plugin height', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Responsive', 'universal-video' );?><br /></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'the plugin will responsive', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the plugin will not be responsive', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Responsive Relative To Browser', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?><br />
      <strong>true</strong> - <?php esc_html_e( 'the plugin will be responisve relatively to browser dimensions', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the plugin will be responisve relatively to parent div', 'universal-video' );?></td>
  </tr>
	<tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Center Player', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?><br />
      <strong>true</strong> - <?php esc_html_e( 'the player will be centered on the page', 'universal-video' );?><br />
      <strong>false</strong> -  <?php esc_html_e( 'the player will notbe centered on the page, it will be left align', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Automatically Obtain Thumb, Title &amp; Description From YouTube Server', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?><br />
      <strong>true</strong> - <?php esc_html_e( 'the plugin will obtain the movie thumb,   movie title and movie description from YouTube server IF in playlist   code these data is missing', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the plugin will use the movie thumb, movie title and movie description defined in playlist code', 'universal-video' );?></td>
  </tr>
  <tr>
    <td width="30%" align="left" valign="top" class="row-title"><?php esc_html_e( 'Shuffle', 'universal-video' );?></td>
    <td width="83%" align="left" valign="top"><?php esc_html_e( 'Possible values: ', 'universal-video' );?><br />
      <strong>true</strong> - <?php esc_html_e( 'the playlist will be played in shuffle mode', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the playlist will be played in normal mode', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Player Height', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Define which video will be the first one to load. The counting starts from 0', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Initial Volume', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'You can initialize the volume. The range is 0 to 1', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Loop', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values: ', 'universal-video' );?><br />
      <strong>true</strong> - <?php esc_html_e( 'the plugin will loop the playlist when it reaches the end', 'universal-video' );?><br />
    <strong>false</strong> - <?php esc_html_e( 'the plugin will stop when reaches the end', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Facebook AppID', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'FaceBook AppID. Please check', 'universal-video' );?> <a href="#facebook_share"><?php esc_html_e( 'Facebook Share', 'universal-video' );?></a> <?php esc_html_e( 'section, for more informations', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Facebook Share Title', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The title which will appear on FaceBook share. Please check', 'universal-video' );?> <a href="#facebook_share"><?php esc_html_e( 'Facebook Share', 'universal-video' );?></a> <?php esc_html_e( 'section, for more informations', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Facebook Share Description', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The description which will appear on FaceBook share. Please check', 'universal-video' );?> <a href="#facebook_share"><?php esc_html_e( 'Facebook Share', 'universal-video' );?></a> <?php esc_html_e( 'section, for more informations', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Show Search', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'the search area will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the search area  will not appear ', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Search Area Bg', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Search area  background color (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Search Input Text', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Search input initial text, useful for translation purpose', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Search Input Bg', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Search input  background color (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Search Input Border Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Search input  border color (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Search Input Text Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Search input  text color (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Player Border Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'border color (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Controls Bg FullScreen Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Controllers background color when the player is in full-screen mode (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Show Logo', 'universal-video' );?></td>
    <td align="left" valign="top"><p><?php esc_html_e( 'Show top,left logo', 'universal-video' );?></p>
    <p><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'the logo will appear', 'universal-video' );?><br />
    <strong>false</strong> - <?php esc_html_e( 'the logo will not appear', 'universal-video' );?></p></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Logo Image Path', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The path to the logo image', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Logo Link', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The link which will be opened when the logo will be clicked', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Logo Target', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Logo link target', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Auto-Play First Video', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'the first video will autoplay', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the first video will not autoplay', 'universal-video' );?></td>
  </tr>
	<tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Auto-Play On Mobile', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'the first video will autoplay on mobile devices', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the first video will not autoplay on mobile devices', 'universal-video' );?></td>
  </tr>
	<tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Advance To Next Video', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'starts next movie after the current movie has finished', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( "doesn't start next movie after the current movie has finished", "universal-video" );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Top Title Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The top,left movie title color (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Timer Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The top,right movie timer color (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Buffer Empty Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Movie buffer color, empty state (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Buffer Full Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Movie buffer color, full state (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Seekbar Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Movie seekbar color (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Volume Off Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Volume color, OFF state (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Volume On Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Volume  color, ON state (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Play But Color Off', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Play/Pause button background color, OFF state (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Play But Color On', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Play/Pause button background color, ON state (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Show Top Title', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'the top,left movie title will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the top,left movie title will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Suggested Quality', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'ONLY FOR YOUTUBE. This parameter value can be:', 'universal-video' );?><br />
      - small, <br />
      - medium<br />
      - large<br />
      - hd720<br />
      - hd1080<br />
      - highres or <br />
      - default. <br />
  <p><?php esc_html_e( 'YouTube  recommends that you set the parameter value to default,   which instructs YouTube to select the most appropriate playback   quality, which will vary for different users, videos, systems and other   playback conditions.', 'universal-video' );?></p></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Show Timer', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'the top,right movie timer will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the top,right movie timer  will not appear ', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Activate Google Analytics Tracking', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'Google Analytics tracking will be enabled', 'universal-video' );?><br />
    <strong>false</strong> - <?php esc_html_e( 'Google Analytics tracking will be disabled', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Your Google Analytics Tracking Code', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Your  Google Analytics code.', 'universal-video' );?><br />
      <?php esc_html_e( 'Example:', 'universal-video' );?> UA-3245593-1</td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="left" valign="top" class="lbg_regGray"><?php esc_html_e( 'Controllers Settings: Show/Hide buttons &amp; elements', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Rewind But', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'rewind button will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'rewind button will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Play But', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'play/pause button will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'play/pause   button will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show  Volume But', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'volume button will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'volume   button will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Twitter But', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'twitter button will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'twitter button will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Info But', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'info button will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'info   button will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Download But', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'download button will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'download track button will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Playlis tBut', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'show/hide playlist button will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'show/hide playlist  button will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Fullscreen But', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'fullscreen button will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'fullscreen   button will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Shuffle But', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'shuffle button will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'shuffle button will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show NextPrevBut', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'next/previous buttons will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'next/previous buttons will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Facebook But', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'facebook button will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'facebook button will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="left" valign="top" class="lbg_regGray"><?php esc_html_e( 'Playlist  Settings', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Playlist On Init', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'playlist will appear on init', 'universal-video' );?><br />
    <strong>false</strong> - <?php esc_html_e( 'playlist will not appear on init', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist  Width', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist width', 'universal-video' );?></td>
  </tr>
	<tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Playlist At The Bottom When the Resolution Is Less Than', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'For mobile devices, the playlist will be displayed at the bottom of the player (instead of right-side) when the device width is less than this parameter value', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Scroller Bg Color OFF', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist scroll-bar OFF color (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Scroller Bg Color ON', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist scroll-bar ON color (hexa)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Number Of Thumbs Per Screen', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'the number of thumbs per screen. If you set it to 0, it will be calculated automatically. You can set a fixed number, for example 3', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Thumbs', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'the  thumbs from playlist will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the thumbs from playlist will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Title', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'the tile from playlist  will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the tilte from playlist  will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Description', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'the description from playlist will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the description from playlist will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Record Height', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record height', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Record Padding', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record padding', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Title Font Size', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record title font size', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Title Line Height', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record title line-height', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Desc Font Size', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record decription font size', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Desc Line Height', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record descripton line-height', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Record Bg Off Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( '<p>The playlist record background color (OFF state). </p>', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Record Title Off Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record title color (OFF state)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Record Desc Off Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record description color (OFF state)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Record Bg Off Img Opacity', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record opacity value (OFF state). It can take values between 0-100', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Record Bg On Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record background color (ON state).', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Record Title On Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record title color (ON state)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Record Desc On Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record description color (ON state)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Record Bg On Img Opacity', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record opacity value (ON state). It can take values between 0-100', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist Bg Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record background color.', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist RecordTitleLimit', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record title characters limit. All the other characters will be remoeved and replaced with ...', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Playlist RecordDescLimit', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The playlist record description characters limit. All the other characters will be remoeved and replaced with ...', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Thumb Width', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'playlist thumbnail width (for skins that have a thumbnail)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Thumb Height', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'playlist thumbnail height (for skins that have a thumbnail)', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="left" valign="top" class="lbg_regGray"><?php esc_html_e( 'Category  Settings', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Show Categs', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Possible values:', 'universal-video' );?> <br />
      <strong>true</strong> - <?php esc_html_e( 'the categories will appear', 'universal-video' );?><br />
      <strong>false</strong> - <?php esc_html_e( 'the categories will not appear', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'First Selected Category', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'The name of the first displayed category (in the top of the playlist). If no value is selected, since the categories will be alphabetically ordered,  the first one will be displayed as the first selected category', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Selected  Categ Bg', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Selected category background color (hexa) or "transparent" value', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Selected Categ Off Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Selected category color (hexa) - OFF state', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Selected Categ On Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Selected category color (hexa) - ON state', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Category Record Bg Off Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Category item background color (hexa) - OFF state', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Category Record Bg On Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Category item background color (hexa) - ON state', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Category Record Bottom Border Off Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Category item bottom border color (hexa) - OFF state', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Category Record Bottom Border On Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Category item bottom border color (hexa) - ON state', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Category Record Text Off Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Category item text color (hexa) - OFF state', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="regb"><?php esc_html_e( 'Category Record Text On Color', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Category item text color (hexa) - ON state', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
<p><span class="lbg_subtitle"><a name="playlist" id="playlist"></a><?php esc_html_e( 'Playlist', 'universal-video' );?></span></p>
<table class="wp-list-table widefat fixed pages" cellspacing="0">
  <tr>
    <td width="30%" align="left" valign="top" class="row-title"></td>
    <td width="70%" align="left" valign="top"></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Title', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'video file title', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Description', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'video file description', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Category', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'video file category. An video file can belong to multiple categories', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Playlist image', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'video file  playlist image', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'YouTube', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( "If you want to play a YouTube video on this slide, you'll insert the YouTube video ID. A YouTube link is of this form", "universal-video" );?> https://www.youtube.com/watch?v=<span class="style1">5WAkvu5Tnkw</span> <br />
<?php esc_html_e( 'The value of "v" parameter  is the ID you need.', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Vimeo', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( "If you want to play a Vimeo video on this slide, you'll insert the Vimeo video ID. A Vimeo link is of this form", "universal-video" );?> https://vimeo.com/<span class="style1">21288282</span><br />
<?php esc_html_e( 'Vimeo', 'The last number of the link is the ID', 'universal-video' );?> </td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Self Hosted/Third Party Hosted Video .MP4 file', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( "If you want to play a Self-Hosted video on this slide, you'll insert the path to the .mp4 file. You need to also add the path to the .webm file, to assure all browsers compatibility (please check the next parameter)", "universal-video" );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Self Hosted/Third Party Hosted Video .WEBM file', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( "If you want to play a Self-Hosted video on this slide, you'll insert the path to the .webm file. You need to also add the path to the .mp4 file,  to assure all browsers compatibility (please check the previous parameter)", "universal-video" );?></td>
  </tr>
	<tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Optional Start Time', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Optional parameter to set the video start time', 'universal-video' );?></td>
  </tr>
	<tr>
    <td align="left" valign="top" class="row-title"><?php esc_html_e( 'Optional End Time', 'universal-video' );?></td>
    <td align="left" valign="top"><?php esc_html_e( 'Optional parameter to set the video end time', 'universal-video' );?></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span class="lbg_subtitle"><a name="facebook_share" id="facebook_share"></a><?php esc_html_e( '7. FaceBook Share', 'universal-video' );?></span></p>
<p><?php esc_html_e( 'In order for the Facebook share button to work you need to obtain a Facebook Application ID', 'universal-video' );?></p>
<p><?php esc_html_e( '1. Go to the ', 'universal-video' );?><a href="https://developers.facebook.com/apps" target="_blank"><?php esc_html_e( 'Facebook Developers Apps page', 'universal-video' );?></a> <?php esc_html_e( 'and and sign in with your Facebook username and password.', 'universal-video' );?></p>
<p><?php esc_html_e( '2. Click the &quot;Create New App&quot; button.', 'universal-video' );?></p>
<p><i><?php esc_html_e( 'If you do not see the option to create a new app in the upper right hand corner, click on &quot;Register as Developer.&quot;', 'universal-video' );?></i> </p>
<p><?php esc_html_e( "3. After that you'll obtain an 'App ID' which you'll paste in ", "universal-video" );?><span class="regb"><?php esc_html_e( 'FaceBook AppID', 'universal-video' );?></span> <?php esc_html_e( 'field in Manage Players->Player Settings area of our plugin', 'universal-video' );?></p>
<p><?php esc_html_e( "4. Go to Settings->Basic tab (left area), select 'Website' and insert your website URL and fill all the other information. Below you have a demo screenshot. Of course, you'll use your own info.", "universal-video" );?></p>
<p><img src="<?php echo plugins_url('images/facebookAppId.jpg', dirname(__FILE__))?>" width="1600" height="1511" alt="facebook appid" /></p>
<p><?php esc_html_e( '5. Go to Settings->Advanced tab (left area) and activate "Social Discovery"', 'universal-video' );?></p>
<p><img src="<?php echo plugins_url('images/status_and_review.jpg', dirname(__FILE__))?>" width="1600" height="770" alt="status and review" /></p>
<p><?php esc_html_e( '6. To personalize more the share content you can use ', 'universal-video' );?><span class="regb"><?php esc_html_e( 'FaceBook Share Title	', 'universal-video' );?></span> <?php esc_html_e( 'and', 'universal-video' );?> <span class="regb"><?php esc_html_e( 'FaceBook Share Description', 'universal-video' );?>		</span> <?php esc_html_e( 'fields in Manage Players->Player Settings area of our plugin. Please check', 'universal-video' );?> <a href="#settings"><?php esc_html_e( 'Player Settings', 'universal-video' );?></a> <?php esc_html_e( 'section, to see all available parameters', 'universal-video' );?></p>
<p></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span class="lbg_subtitle"><a name="shortcode" id="shortcode"></a><?php esc_html_e( 'ShortCode', 'universal-video' );?></span></p>
<p><?php esc_html_e( 'The shortcode is:', 'universal-video' );?> <br />
[universal_video_player settings_id='1']<br />
<?php esc_html_e( 'where', 'universal-video' );?> <br />
<?php esc_html_e( 'settings_id is the player ID defined in &quot;Manage Players&quot; section', 'universal-video' );?></p>
<p><?php esc_html_e( 'OPTIONAL PARAMETERS:', 'universal-video' );?></p>
<?php esc_html_e( 'videos_initial_ord - it can be used to define which video items, from the playlist, will appear in the player. It will take the value of the playlist item order.', 'universal-video' );?>
<p>[universal_video_player settings_id='1' videos_initial_ord='4,2,5'] - <?php esc_html_e( 'in this case, only the playlist items which have  4 or 2 or 5 as "Initial Order" will be in the playlist', 'universal-video' );?></p>
<p>&nbsp;</p>
<p><span class="lbg_subtitle"><a name="htaccess" id="htaccess"></a>.htaccess</span></p>
<p><?php esc_html_e( 'If you need to increase the wordpress media library upload file size limit add the following definitions in the .htaccess file', 'universal-video' );?></p>
<p>&lt;IfModule mod_php5.c&gt;<br />
  php_value post_max_size           10M<br />
  php_value upload_max_filesize     40M<br />
  php_value memory_limit            500M<br />
  &lt;/IfModule&gt;</p>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span class="lbg_subtitle"><a name="api" id="api"></a><?php esc_html_e( 'API function', 'universal-video' );?></span></p>
<p><?php esc_html_e( 'You can change the category by adding a javascript function to a button on the page.', 'universal-video' );?></p>
<p>jQuery.universal_video_player.changePlaylist('category_title');</p>
<p>&nbsp;</p>
<p><?php esc_html_e( 'Example:', 'universal-video' );?></p>
<textarea rows="3" style="width:100%;"><a href="javascript:void(0)" onclick="jQuery.universal_video_player.changePlaylist('Classic');">Select Classic Category</a></textarea>
<p>&nbsp;</p>
