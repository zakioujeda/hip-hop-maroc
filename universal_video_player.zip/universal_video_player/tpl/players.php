<div class="wrap">
	<div id="lbg_logo">
			<h2><?php esc_html_e( 'Manage Players', 'universal-video' );?></h2>
 	</div>
    <div><p><?php esc_html_e( 'From this section you can add multiple players.', 'universal-video' );?></p></div>

    <div id="previewDialog"><iframe id="previewDialogIframe" src="" width="100%" height="600" class="lbg_b0"></iframe></div>

<div class="lbg_cent_p0"><img src="<?php echo plugins_url('images/icons/add_icon.gif', dirname(__FILE__))?>" alt="add" align="absmiddle" /> <a href="?page=UNIVERSAL_VIDEO_PLAYER_Add_New"><?php esc_html_e( 'Add new (player)', 'universal-video' );?></a></div>

<table width="100%" class="widefat">

			<thead>
				<tr>
					<th scope="col" width="6%"><?php esc_html_e( 'ID', 'universal-video' );?></th>
					<th scope="col" width="23%"><?php esc_html_e( 'Name', 'universal-video' );?></th>
					<th scope="col" width="24%"><?php esc_html_e( 'Shortcode', 'universal-video' );?></th>
					<th scope="col" width="36%"><?php esc_html_e( 'Action', 'universal-video' );?></th>
					<th scope="col" width="11%"><?php esc_html_e( 'Preview', 'universal-video' );?></th>
				</tr>
			</thead>

<tbody>
<?php foreach ( $result as $row )
	{
		$row=universal_video_player_unstrip_array($row); ?>
							<tr class="alternate author-self status-publish" valign="top">
					<td><?php esc_html_e($row['id'])?></td>
					<td><?php esc_html_e($row['name'])?></td>
					<td>[universal_video_player settings_id='<?php esc_html_e($row['id'])?>']</td>
					<td>
						<a href="?page=UNIVERSAL_VIDEO_PLAYER_Settings&amp;id=<?php echo esc_attr($row['id'])?>&amp;name=<?php echo esc_attr($row['name'])?>"><?php esc_html_e( 'Player Settings', 'universal-video' );?></a> &nbsp;&nbsp;|&nbsp;&nbsp;
						<a href="?page=UNIVERSAL_VIDEO_PLAYER_Playlist&amp;id=<?php echo esc_attr($row['id'])?>&amp;name=<?php echo esc_attr($row['name'])?>"><?php esc_html_e( 'Playlist', 'universal-video' );?></a> &nbsp;&nbsp;|&nbsp;&nbsp;
                        <a href="?page=UNIVERSAL_VIDEO_PLAYER_Manage_Players&id=<?php echo esc_attr($row['id'])?>" onclick="return confirm('Are you sure?')" class="lbg_the_red"><?php esc_html_e( 'Delete', 'universal-video' );?></a> &nbsp;&nbsp;|&nbsp;&nbsp;
                        <a href="?page=UNIVERSAL_VIDEO_PLAYER_Duplicate_Player&amp;id=<?php echo esc_attr($row['id'])?>&amp;name=<?php echo esc_attr($row['name'])?>"><?php esc_html_e( 'Duplicate', 'universal-video' );?></a>
                        </td>
					<td><a href="javascript: void(0);" onclick="showDialogPreview(<?php echo esc_js($row['id'])?>)"><img src="<?php echo plugins_url('images/icons/magnifier.png', dirname(__FILE__))?>" alt="preview" border="0" align="absmiddle" /></a></td>
	            </tr>
<?php } ?>
						</tbody>
		</table>





</div>
