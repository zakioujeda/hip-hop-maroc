<script src="<?php echo plugins_url('../js/lbg_addplaylist_page.js', __FILE__); ?>" type="text/javascript"></script>

<div class="wrap">
	<div id="lbg_logo">
			<h2><?php esc_html_e( 'Playlist for player:', 'universal-video' );?> <span class="lbg_the_redb"><?php esc_html_e($_COOKIE['xname'])?> - <?php esc_html_e( 'ID', 'universal-video' );?> #<?php echo esc_html_e($_COOKIE['xid'])?></span> - <?php esc_html_e( 'Add New', 'universal-video' );?></h2>
 	</div>

    <form method="POST" enctype="multipart/form-data" id="form-add-playlist-record">
	    <input name="playerid" type="hidden" value="<?php echo esc_attr($_COOKIE['xid'])?>" />
		<table class="wp-list-table widefat fixed pages" cellspacing="0">
		  <tr>
		    <td align="left" valign="middle" width="25%">&nbsp;</td>
		    <td align="left" valign="middle" width="77%"><a href="?page=UNIVERSAL_VIDEO_PLAYER_Playlist"class="lbg_pdleft25"><?php esc_html_e( 'Back to Playlist', 'universal-video' );?></a></td>
		  </tr>
		  <tr>
		    <td colspan="2" align="center" valign="middle">&nbsp;</td>
		  </tr>
		  <tr>
		    <td align="right" valign="middle" class="row-title"><?php esc_html_e( 'Set It First', 'universal-video' );?></td>
		    <td align="left" valign="top"><input name="setitfirst" type="checkbox" id="setitfirst" value="1" checked="checked" />
		      <label for="setitfirst"></label></td>
	      </tr>
		  <tr>
		    <td align="right" valign="middle" class="row-title"><?php esc_html_e( 'Title', 'universal-video' );?></td>
		    <td align="left" valign="top"><input name="title" type="text" size="80" id="title" value="<?php echo (array_key_exists('title', $_POST))?strip_tags($_POST['title']):''?>"/></td>
		  </tr>
		  <tr>
		    <td align="right" valign="middle" class="row-title"><?php esc_html_e( 'Description', 'universal-video' );?></td>
		    <td align="left" valign="top">
            <textarea name="desc" cols="75" rows="6"><?php echo (array_key_exists('desc', $_POST))?strip_tags($_POST['desc']):''?></textarea>
            </td>
		  </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Category', 'universal-video' );?></td>
		    <td align="left" valign="top"><?php foreach ( $result as $row )
				{
					if ( !array_key_exists('category', $_POST) ) {
						$_POST['category']=array();
					}

					$row=universal_video_player_unstrip_array($row); ?>
				<p><input name="category[]" id="category" type="checkbox" value="<?php echo esc_attr($row['id']);?>" <?php echo ( in_array($row['id'],$_POST['category']) )?'checked="checked"':''?> /> <?php esc_html_e($row['categ']);?></p>
				<?php }	?></td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Playlist Image ', 'universal-video' );?></td>
		    <td align="left" valign="top"><input name="imgplaylist" type="text" id="imgplaylist" size="80" value="<?php echo (array_key_exists('imgplaylist', $_POST))?strip_tags($_POST['imgplaylist']):''?>" /> <input name="upload_imgplaylist_button" type="button" id="upload_imgplaylist_button" value="Upload Image" />
		      <br />
		      <?php esc_html_e( 'Enter an URL or upload an image', 'universal-video' );?></td>
	      </tr>
          <tr>
            <td align="right" valign="top" class="row-title"><?php esc_html_e( 'YouTube Video ID', 'universal-video' );?></td>
            <td align="left" valign="top"><input name="youtube" type="text" size="60" id="youtube" value="<?php echo (array_key_exists('youtube', $_POST))?strip_tags($_POST['youtube']):''?>"/></td>
          </tr>
          <tr>
            <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Vimeo Video ID', 'universal-video' );?></td>
            <td align="left" valign="top"><input name="vimeo" type="text" size="60" id="vimeo" value="<?php echo (array_key_exists('vimeo', $_POST))?strip_tags($_POST['vimeo']):''?>"/></td>
          </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Self Hosted/Third Party Hosted Video .MP4 file', 'universal-video' );?></td>
		    <td align="left" valign="top"><input name="mp4" type="text" id="mp4" size="80" value="<?php echo (array_key_exists('mp4', $_POST))?strip_tags($_POST['mp4']):''?>" />
		      <input name="upload_mp4_button" type="button" id="upload_mp4_button" value="Upload File" />
		      <br />
		      <?php esc_html_e( 'Enter an URL or upload the file', 'universal-video' );?></td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Self Hosted/Third Party Hosted Video .WEBM file', 'universal-video' );?></td>
		    <td align="left" valign="top"><input name="webm" type="text" id="webm" size="80" value="<?php echo (array_key_exists('webm', $_POST))?strip_tags($_POST['webm']):''?>" />
		      <input name="upload_webm_button" type="button" id="upload_webm_button" value="Upload File" />
		      <br />
		      <?php esc_html_e( 'Enter an URL or upload the file', 'universal-video' );?></td>
	      </tr>
        <tr>
			    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Optional Start Time', 'universal-video' );?></td>
			    <td align="left" valign="top"><input name="startpoint" type="text" size="60" id="startpoint" value="<?php echo (array_key_exists('startpoint', $_POST))?strip_tags($_POST['startpoint']):''?>"/> <?php esc_html_e( 'HH:MM:SS', 'universal-video' );?></td>
		      </tr>
					<tr>
				    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Optional End Time', 'universal-video' );?></td>
				    <td align="left" valign="top"><input name="endpoint" type="text" size="60" id="endpoint" value="<?php echo (array_key_exists('endpoint', $_POST))?strip_tags($_POST['endpoint']):''?>"/> <?php esc_html_e( 'HH:MM:SS', 'universal-video' );?></td>
			      </tr>
		  <tr>
            <td align="right" valign="top" class="row-title">&nbsp;</td>
		    <td align="left" valign="top">&nbsp;</td>
	      </tr>
		  <tr>
		    <td colspan="2" align="center" valign="middle"><input name="Submit" id="Submit" type="submit" class="button-primary" value="Add Record"></td>
		  </tr>
		</table>
  </form>






</div>
